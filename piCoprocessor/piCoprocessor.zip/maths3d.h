#ifndef  MATHS3D_H_
#define  MATHS3D_H_


class maths3d
{
    public:
        const Matrix ident_matrix;
        double vector_dot_product (Vector *vec1, Vector *vec2);                                                                             
        void multiply_vector_by_matrix (Vector *vec,  Matrix *mat);
        void multiply_matrix_by_matrix (Vector *mat1, Matrix *mat2);
        static Vector normalise(Vector *vec );
        static void set_identity(Vector *mat);
        static void orthagonise(Vector *mat);
};

#endif