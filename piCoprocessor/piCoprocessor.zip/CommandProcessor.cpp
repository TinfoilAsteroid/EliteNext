#include "CommandProcessor.h"



CommandProcessor::CommandProcessor()
{
    CommandProcessor::commandTable[enumCommands::Initialise          ].set(enumCommands::Initialise             ,false,    false, 0);
    commandTable[enumCommands::BinaryIOMode        ].set(enumCommands::BinaryIOMode           ,true,     false, &CommandProcessor::binaryIOMode);
    commandTable[enumCommands::TextIOMode          ].set(enumCommands::TextIOMode             ,true,     false, &CommandProcessor::textIOMode);
    commandTable[enumCommands::FetchError          ].set(enumCommands::FetchError             ,false,    false, 0);
    commandTable[enumCommands::UpdateAll           ].set(enumCommands::UpdateAll              ,false,    true,  0);
    commandTable[enumCommands::GetUpdateStatus     ].set(enumCommands::GetUpdateStatus        ,false,    false, 0);
    commandTable[enumCommands::SelectShip          ].set(enumCommands::SelectShip             ,false,    false, 0);
    commandTable[enumCommands::CreateShip          ].set(enumCommands::CreateShip             ,false,    false, 0);
    commandTable[enumCommands::ExplodeShip         ].set(enumCommands::ExplodeShip            ,false,    false, 0);
    commandTable[enumCommands::DestroyShip         ].set(enumCommands::DestroyShip            ,false,    false, 0);
    commandTable[enumCommands::GetPosition         ].set(enumCommands::GetPosition            ,false,    false, 0);
    commandTable[enumCommands::GetShipMatrix       ].set(enumCommands::GetShipMatrix          ,false,    false, 0);
    commandTable[enumCommands::GetShipLineCount    ].set(enumCommands::GetShipLineCount       ,false,    false, 0);
    commandTable[enumCommands::GetShipLineList     ].set(enumCommands::GetShipLineList        ,false,    false, 0);
    commandTable[enumCommands::SetSun              ].set(enumCommands::SetSun                 ,false,    false, 0);
    commandTable[enumCommands::GetSunPosition      ].set(enumCommands::GetSunPosition         ,false,    false, 0);
    commandTable[enumCommands::GetSunMatrix        ].set(enumCommands::GetSunMatrix           ,false,    false, 0);
    commandTable[enumCommands::GetSunLineCount     ].set(enumCommands::GetSunLineCount        ,false,    false, 0);
    commandTable[enumCommands::GetSunLineList      ].set(enumCommands::GetSunLineList         ,false,    false, 0);
    commandTable[enumCommands::SetPlanet           ].set(enumCommands::SetPlanet              ,false,    false, 0);
    commandTable[enumCommands::GetPlanetPosition   ].set(enumCommands::GetPlanetPosition      ,false,    false, 0);
    commandTable[enumCommands::GetPlanetMatrix     ].set(enumCommands::GetPlanetMatrix        ,false,    false, 0);
    commandTable[enumCommands::GetPlanetLineCount  ].set(enumCommands::GetPlanetLineCount     ,false,    false, 0);
    commandTable[enumCommands::GetPlanetLineList   ].set(enumCommands::GetPlanetLineList      ,false,    false, 0);
    commandTable[enumCommands::GetShipInSightCount ].set(enumCommands::GetShipInSightCount    ,false,    false, 0);
    commandTable[enumCommands::GetShipsInSightList ].set(enumCommands::GetShipsInSightList    ,false,    false, 0);
    commandTable[enumCommands::GetShipTargetId     ].set(enumCommands::GetShipTargetId        ,false,    false, 0);
    commandTable[enumCommands::SetShipTargetId     ].set(enumCommands::SetShipTargetId        ,false,    false, 0);
    commandTable[enumCommands::GetShipType         ].set(enumCommands::GetShipType            ,false,    false, 0);
    commandTable[enumCommands::GetShipStatus       ].set(enumCommands::GetShipStatus          ,false,    false, 0);
    commandTable[enumCommands::RoateShipToTarget   ].set(enumCommands::RoateShipToTarget      ,false,    false, 0);
    commandTable[enumCommands::RotateShipToShipN   ].set(enumCommands::RotateShipToShipN      ,false,    false, 0);
    commandTable[enumCommands::RotateShipToPlayer  ].set(enumCommands::RotateShipToPlayer     ,false,    false, 0);
    commandTable[enumCommands::PitchShipToTarget   ].set(enumCommands::PitchShipToTarget      ,false,    false, 0);
    commandTable[enumCommands::PitchShipToShipN    ].set(enumCommands::PitchShipToShipN       ,false,    false, 0);
    commandTable[enumCommands::PitchShipToPlayer   ].set(enumCommands::PitchShipToPlayer      ,false,    false, 0);
    commandTable[enumCommands::RollShipToTarget    ].set(enumCommands::RollShipToTarget       ,false,    false, 0);
    commandTable[enumCommands::RollShipToShipN     ].set(enumCommands::RollShipToShipN        ,false,    false, 0);
    commandTable[enumCommands::RollShipToPlayer    ].set(enumCommands::RollShipToPlayer       ,false,    false, 0);
    commandTable[enumCommands::AdjustSpeedToTarget ].set(enumCommands::AdjustSpeedToTarget    ,false,    false, 0);
    commandTable[enumCommands::AdjustSpeedToShipN  ].set(enumCommands::AdjustSpeedToShipN     ,false,    false, 0);
    commandTable[enumCommands::AdjustSpeedToPlayer ].set(enumCommands::AdjustSpeedToPlayer    ,false,    false, 0);
    commandTable[enumCommands::NormaliseVector     ].set(enumCommands::NormaliseVector        ,false,    false, &CommandProcessor::normalise);
    commandTable[enumCommands::OrthagnoaliseMatrix ].set(enumCommands::OrthagnoaliseMatrix    ,true,     false, &CommandProcessor::orthagnonaliseMatrix);,
    commandTable[enumCommands::SquareRoot          ].set(enumCommands::SquareRoot             ,true,     false, &CommandProcessor::squareRoot);
    commandTable[enumCommands::VectMulMatrix       ].set(enumCommands::VectMulMatrix          ,true,     false, &CommandProcessor::vectMulMatrix);
    commandTable[enumCommands::DotProduct          ].set(enumCommands::DotProduct             ,true,     false, &CommandProcessor::dotProduct);
    commandTable[enumCommands::GetIdentitymatrix   ].set(enumCommands::GetIdentitymatrix      ,false,    false, 0);
    commandTable[enumCommands::Exit                ].set(enumCommands::Exit                   ,false,    false, 0);
}

            bool    CommandProcessor::processCommand  (enumCommands command)
            {
                if (command > Exit}
                {
                    return false;
                }
                else
                {
                    if (commandtable[command].implemented == false)
                    {
                        return false;
                    }
                    else
                    {
                        (*commandtable[command].processorFn());
                        return true;
                    }
                }
            }


        /* binaryIOMode - sets input output to binary, all numbers are 24 bit lead sign */
        void CommandProcessor::binaryIOMode()
        {
            consoleIO::set_binary_mode();
        }
        /* binaryIOMode - sets input output to text, all numbers are lead sign terminated by separator (separator excluded) */
        void CommandProcessor::textIOMode()
        {
            consoleIO::set_text_mode();
        }
        
        /* normalise
           IN  - vector (3 doubles)
           OUT - vector (3 doubles), if read fails, writes 1,0,0 vector
        */
        void CommandProcessor::normalise()
        {
            vector lVector();
            consoleIO::read_input_buffer();
            if  (consoleIO::readstatus == fileSuccess)
            {
                lVector.x = consoleIO::read_double(0.0);
                lVector.y = consoleIO::read_double(0.0);
                lVector.z = consoleIO::read_double(0.0);
                lVector = maths3D::normalise(lVector);
            }
            else
            {
                lVector.x =0.0;
                lVector.y =0.0;
                lVector.z =0.0;
            }
            consoleIO::write_vector(lVector, sendMode);
            consoleIO::sendBuffer();
        }
        /* square Root
            IN  - double
            OUT - double, if square root can not read input then returns sqrt 1
        */
        void CommandProcessor::squareRoot()
        {
            double  value;
            consoleIO::read_input_buffer();
            if  (consoleIO::readstatus == fileSuccess)
            {
                value = consoleIO::read_double(1.0);
                value = std::sqrt(value);
                consoleIO::writeDouble(value, sendMode);
            }
            else
            {
                consoleIO::writeDouble(1.0f, sendMode);
            }
            consoleIO::sendBuffer();
        }
        
        void CommandProcessor::vectMulMatrix()
        {
            vector  vect;
            matrix  mat;
            consoleIO::read_input_buffer();
            if  (consoleIO::readstatus == fileSuccess)
            {
                vect = consoleIO::read_vector(defaultVector);
                mat  = consoleIO::read_vector(defaultMatrix);
                maths3d::multiply_vector_by_matrix(&vect,mat)
                consoleIO::writeVector(&vect, append);
            }
            else
            {
                consoleIO::writeVector(defaultVector, sendMode);
            }
            consoleIO::sendBuffer();
        }
        
        void CommandProcessor::orthagnonaliseMatrix()
        {
            matrix mat;
            consoleIO::read_input_buffer();
            if  (consoleIO::readstatus == fileSuccess)
            {
                mat = consoleIO::read_matrix(defaultMatrix);
                maths3d::orthagonise(&mat)
                consoleIO::writeMatrix(mat, sendMode);
            }
            else
            {
                consoleIO::writeMatrix(defaultMatrix, sendMode);
            }
            consoleIO::sendBuffer();
        }
            
        void CommandProcessor::dotProduct()
        {
            vector vec1;
            vector vec2;
            consoleIO::read_input_buffer();
            if  (consoleIO::readstatus == fileSuccess)
            {
                vec1 = consoleIO::read_vector(defaultVector);
                vec2 = consoleIO::read_vector(defaultVector);
                maths3d::vector_dot_product(&vec1,&vec2);
                consoleIO::writeVector(vec1, sendMode);
            }
            else
            {
                consoleIO::writeVector(defaultVector, sendMode);
            }
            consoleIO::sendBuffer();
        }
                
         void CommandProcessor::getIdentitymatrix()
         {
             consoleIO::writeMatrix(maths3D::indentMatrix, sendMode);
             consoleIO::sendBuffer();
         }
};
