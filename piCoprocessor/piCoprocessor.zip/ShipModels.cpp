void ShipModelTable::ShipModeltable(eShipModels shipModeType)
{
    shipModelId = shipModelType;
    nodeCount   = 0;
    lineCount   = 0;
    normalCount = 0;
}
