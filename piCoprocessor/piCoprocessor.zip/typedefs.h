#ifndef  TYPEDEFS_H_
#define  TYPEDEFS_H_
typedef enum
{
    Empty,
    Active,
    Exploding,
    Destroyed
} eShipStatus;

typedef enum
{
    ShipID_Adder,
    ShipID_Anaconda,
    ShipID_Asp_Mk_2,
    ShipID_Boa,
    ShipID_CargoType5,
    ShipID_Boulder,
    ShipID_Asteroid,
    ShipID_Bushmaster,
    ShipID_Chameleon,
    ShipID_CobraMk3,
    ShipID_Cobra_Mk_1,
    ShipID_Cobra_Mk_3_P,
    ShipID_Constrictor,
    ShipID_Coriolis,
    ShipID_Cougar,
    ShipID_Dodo,
    ShipID_Dragon,
    ShipID_Escape_Pod,
    ShipID_Fer_De_Lance,
    ShipID_Gecko,
    ShipID_Ghavial,
    ShipID_Iguana,
    ShipID_Krait,
    ShipID_Logo,
    ShipID_Mamba,
    ShipID_Missile,
    ShipID_Monitor,
    ShipID_Moray,
    ShipID_Ophidian,
    ShipID_Plate,
    ShipID_Python,
    ShipID_Python_P,
    ShipID_Rock_Hermit,
    ShipID_ShuttleType9,
    ShipID_Shuttle_Mk_2,
    ShipID_Sidewinder,
    ShipID_Splinter,
    ShipID_TestVector,
    ShipID_Thargoid,
    ShipID_Thargon,
    ShipID_TransportType10,
    ShipID_Viper,
    ShipID_Worm,
    ShipID_Rattler
} eShipModels;
                    
typedef enum 
{
    fileSuccess, 
    fileNoOperation,
    fileReadFail,
    fileReadNoInput,
    fileBufferEmpty,
    fileWriteFail,
    fileEndOfBuffer
} efileStatus;

typedef enum 
{
    appendMode,
    sendMode
} eAppend;

typedef enum  
{
    binary,
    text
} eWritemode;


// Pullin the ship defintions rather than have them in the z80 code.

typedef enum  {Initialise,
                BinaryIOMode,       TextIOMode,     FetchError
               ,UpdateAll,          GetUpdateStatus
               ,SelectShip,         CreateShip,         ExplodeShip,    DestroyShip
               ,GetPosition,        GetShipMatrix,  GetShipLineCount,   GetShipLineList
               ,SetSun,             GetSunPosition,     GetSunMatrix,   GetSunLineCount,    GetSunLineList
               ,SetPlanet,          GetPlanetPosition,  GetPlanetMatrix,GetPlanetLineCount, GetPlanetLineList
               ,GetShipInSightCount,GetShipsInSightList
               ,GetShipTargetId    ,SetShipTargetId,    GetShipType,    GetShipStatus
               ,RoateShipToTarget,  RotateShipToShipN,  RotateShipToPlayer
               ,PitchShipToTarget,  PitchShipToShipN,   PitchShipToPlayer
               ,RollShipToTarget,   RollShipToShipN,    RollShipToPlayer
               ,AdjustSpeedToTarget,AdjustSpeedToShipN, AdjustSpeedToPlayer
               ,NormaliseVector,    OrthagnoaliseMatrix,SquareRoot
               ,VectMulMatrix,      DotProduct,         GetIdentitymatrix
               ,Exit
               } enumCommands;
        
#endif