
#ifndef  COMMANDPROCESSOR_H_
#define  COMMANDPROCESSOR_H_
#include "typedefs.h"
#include "vector.h"
class  CommandTable
{
    public:
            enumCommands  command;
            bool          implemented;
            bool          async;
            void          CommandProcessor::(*processorFn)();
            CommandTable()
            {
                implemented         = false;
            }
            CommandTable (enumCommands pCommand, bool pImplemented, bool pAsync, void (*pProcessorFN)())
            {
                command             = pCommand;
                implemented         = pImplemented;
                async               = pAsync;
                processorFn         = pProcessorFN;
            }
            void set(enumCommands pCommand, bool pImplemented, bool pAsync, void (*pProcessorFN)())
            {
                command             = pCommand;
                implemented         = pImplemented;
                async               = pAsync;
                processorFn         = pProcessorFN;
            }               
};
                      
        
class   CommandProcessor
{
    public:
        CommandProcessor();
        bool    processCommand  (enumCommands command);
        void    ParseCommand(enumCommands commandId);
    
    private:
        Vector  const defaultVector;
        Matrix  const defaultMatrix;
        enumCommands commandToprocess;

        CommandTable commandTable[Exit];


        /* binaryIOMode - sets input output to binary, all numbers are 24 bit lead sign */
        void binaryIOMode();
        void textIOMode();
        void normalise();
        void squareRoot();
        void vectMulMatrix();
        void orthagnonaliseMatrix();
        void dotProduct();

};

#endif