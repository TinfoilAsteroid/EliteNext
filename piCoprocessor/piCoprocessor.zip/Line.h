#ifndef  LINE_H_
#define  LINE_H_

class Line
{
    public:
        Line();
        Line(int x1,int y1,int x2,int y2);
        Line(double x1,double y1,double x2,double y2);
        int clipX1, clipX2;
        int clipY1, clipY2;

    private:
        int xPos1,yPos1;
        int xPos2,yPos2;
        int x1Clipped,y1Clipped;
        int x2Clipped,y2Clipped;
        bool drawable;
        bool point;
/* Methods */

        bool isPoint();
        bool ClipLine();
};
#endif