#ifndef  CONSOLEIO_H_
#define  CONSOLEIO_H_

#include <iostream>
#include <string>
#include <sstream>

#include "typedefs.h"
#include "vector.h"
#include "ShipData.h"

class ConsoleIO
{
    public:
        const  static  int max_buffer = 5000;
        eWritemode  write_mode;
        char        separator;
        char        eolseparator;
        /*Methods*/
        void write_double();
    private:
        char            input_buffer[max_buffer];
        char            output_buffer[max_buffer];
        int             current_buffer_length;
        int             output_buffer_length;
        int             in_buffer_index;
        int             out_buffer_index;
        efileStatus     readstatus;
    public:
        ConsoleIO();
        enumCommands     command_to_binary(); // takes the current command in the input buffer and conversts to binary enum
        void set_text_mode();
        void set_binary_mode();
        int read_text_input_line();
        int get_input_line(char *buffer, int max_length);
        void set_output_line(char *buffer, int max_length);
        
        void read_input_buffer_text();
        void read_input_buffer_binary(int readlength);
        double read_double_text();
        double read_double_binary();
        double read_double(double defaultvalue);
        
        void write_double_text();
        void write_double_binary();
        void write_double(double value, eAppend appendMode);
        void write_vector(Vector vect,eAppend appendMode);
        void write_float(eAppend appendMode);

        efileStatus send_output_buffer();
        efileStatus read_next_byte();
        efileStatus read_input_buffer();
        efileStatus read_input_buffer_clear();
      };

#endif