#ifndef  SHIPDATA_H_
#define  SHIPDATA_H_

#include "Line.h"

class ShipData
{
    public:
        double      xPos,yPos,zPos;
        double      rotate,pitch,acceleration;
        double      speed;
        Matrix      orientation;
        eShipModels ship_model;
        int         ship_id;
        int         ship_id_target;
        eShipStatus status;
        Line        *shipLines;
        /* Methods */
        void        ProcessShip();
        
};
#endif