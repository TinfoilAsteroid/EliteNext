
#include <iostream>

#include "typedefs.h"
#include "consoleIO.h"
#include "maths3d.h"
#include "CommandProcessor.h"
#include "ShipModels.h"
#include "ShipData.h"
/* TO DO
   ready to accept "~" prompt
   z buffer hidden line removal as well as clipping


*/
int main(int argc, char *argv[])
{
    int                 const shipsMax = 12;
    int                 status = 0;
    consoleIO           fileProcessor;
    maths3d             mathsProcessor;
    CommandProcessor    commandProcessor;
    efileStatus         readstatus;
    enumCommands        commandId;
    ShipData            ships[shipsMax];
    ShipModelTable      shipModels[ShipID_Rattler];
    
    while (status == 0)
    {
        readstatus = fileProcessor.read_input_buffer();
        if  (readstatus == fileSuccess)
        {
            commandId = fileProcessor.command_to_binary();
            if (commandId == enumCommands::Exit)
            {
                status == -1;
            }
            else
            {
                commandProcessor.ParseCommand(commandId);
            }
        }
    }
    return 0;
}