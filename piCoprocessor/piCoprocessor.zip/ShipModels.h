#ifndef  SHIPMODELS_H_
#define  SHIPMODELS_H_

#include "Line.h"

class  ShipNode
{
        double  x,y,z;
        double  always_draw_distance;
        int     face1,face2,face3,face4;
};

class  ShipLine
{
        double  always_draw_distance;
        int     face1,face2;
        int     start_node;
        int     end_node;
};

class  ShipFaceNormal
{
        double  always_draw_distance;
        double  x,y,z;
};

class   ShipModel
{
        double  viewDistance;
        double  drawAllFacesDistance;
};
            const   int NodeMax = 60;
            const   int LineMax = 60;
            const   int FaceMax = 60;
            
class   ShipModelTable
{
        public:


            eShipModels      shipModelId;
            int              nodeCount;
            int              lineCount;
            int              normalCount;
            ShipNode         nodes[NodeMax];
            ShipLine         lines[LineMax];
            ShipFaceNormal   normals[FaceMax];
            Line             renderLines[LineMax];

            void ShipModeltable(eShipModels shipModelType)
            {
                shipModelId = shipModelType;
                nodeCount   = 0;
                lineCount   = 0;
                normalCount = 0;
            }
};

#endif