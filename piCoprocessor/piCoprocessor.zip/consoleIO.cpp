
#include <iostream>
#include <fstream>
#include <string>
#include <cstring>
#include <sstream>

#include "typedefs.h"
#include "consoleIO.h"

        ConsoleIO::ConsoleIO()
        {
            current_buffer_length = 0;
            output_buffer_length  = 0;
            in_buffer_index       = 0;
            out_buffer_index      = 0;
            readstatus            = fileNoOperation;
            write_mode            = binary;
            separator             = '|';
            eolseparator          = '\n';// Only used for text, binary mode is always fixed length
        }
        /* sets mode for IO to ascii with 0x13 terminator */
        void ConsoleIO::set_text_mode()    { write_mode = text;   }
        
        /* sets mode for IO as 24 bit integrer for all numbers */
        void ConsoleIO::set_binary_mode()  { write_mode = binary; }
        
        
        void ConsoleIO::read_input_buffer_text()
        {
          
        }
        
        void ConsoleIO::read_input_buffer_binary(int readlength)
        {
 
        }
        
        
        void ConsoleIO::write_double_text()
        {}
        
        void ConsoleIO::write_double_binary()
        {}
        
        double ConsoleIO::read_double_text()
        {
            double readvalue;
            readvalue = 0;
            char a;
            return 0.0;
        }
        
        double ConsoleIO::read_double_binary()
        {
           return 0.0;
        }

        double ConsoleIO::read_double(double defaultvalue)
        {
            double value_read;
            if (write_mode == text)
            {
                value_read = read_double_text();
            }
            else
            {
                value_read =read_double_binary();
            }
            if  (readstatus == fileSuccess)
            {
                return value_read;
            }
            else
            {
                return defaultvalue;
            }
        }
        
        /* if append mode then adds to end of buffer, else wipe buffer first */ 
        void ConsoleIO::write_double(double value, eAppend appendMode)
        {
        }
            
        void ConsoleIO::write_vector(Vector vect,eAppend appendMode)
        {
        }
        
        void ConsoleIO::write_float(eAppend appendMode)
        {
        }
               
        /* In read text all values are separated by | character by default*/
        int ConsoleIO::read_text_input_line()
        {
            return 0;
        }
        
        
        int ConsoleIO::get_input_line(char *buffer, int max_length)
        {
            return 0;
        }
        
        void ConsoleIO::set_output_line(char *buffer, int max_length)
        {
        }
        

        efileStatus ConsoleIO::send_output_buffer()
        {
            return fileReadFail;
        }
        
        efileStatus ConsoleIO::read_next_byte()
        {
             return fileReadFail;
        }
        
        efileStatus ConsoleIO::read_input_buffer()
        {
            return fileReadFail;
        }

        efileStatus ConsoleIO::read_input_buffer_clear()
        {
            in_buffer_index       = 0;
            current_buffer_length = 0;
            return read_input_buffer();
        }