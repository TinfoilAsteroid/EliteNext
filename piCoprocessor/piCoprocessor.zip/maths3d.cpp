
        double maths3d::vector_dot_product (Vector *vec1, Vector *vec2)
        {
            return (vec1->x * vec2->x) + (vec1->y * vec2->y) + (vec1->z * vec2->z);	
        }
                                                                             
        void maths3d::multiply_vector_by_matrix (Vector *vec, Matrix *mat)
        {
            double x;
            double y;
            double z;

            x = (vec->x * mat[0].x) + (vec->y * mat[0].y) +(vec->z * mat[0].z);
            y = (vec->x * mat[1].x) + (vec->y * mat[1].y) + (vec->z * mat[1].z);
            z = (vec->x * mat[2].x) + (vec->y * mat[2].y) + (vec->z * mat[2].z);

            vec->x = x;
            vec->y = y;
            vec->z = z;
        }

        void maths3d::multiply_matrix_by_matrix (Matrix *mat1, Matrix *mat2)
        {
            int i;
            Matrix rv;
        
            for (i = 0; i < 3; i++)
            {
                rv[i].x =	(mat1[0].x * mat2[i].x) +(mat1[1].x * mat2[i].y) +(mat1[2].x * mat2[i].z);
                rv[i].y =	(mat1[0].y * mat2[i].x) +(mat1[1].y * mat2[i].y) +(mat1[2].y * mat2[i].z);
                rv[i].z =	(mat1[0].z * mat2[i].x) +(mat1[1].z * mat2[i].y) +(mat1[2].z * mat2[i].z);
            }
        
            for (i = 0; i < 3; i++) 
            {
                mat1[i] = rv[i];
            }sdd
        }

        static maths3d::vector normalise(Vector *vec )
        {
            double lx,ly,lz;
            double uni
            struct vector res
        
            lx = vec->x;
            ly = vec->y;
            lz = vec->z;
            uni = sqrt ((lx*lx)+(ly*ly)+(lz*lz));
            res.x = lx/uni;
            res.y = ly/uni;
            res.z = lz/uni;
        
        }
        
        static maths3d::void set_identity(Vector *mat)
        {
            for (int I = 0; I < 3; i++)
            {
                mat[i] = indentity_matrix[i];
            }
        }
        
        static maths3d::void orthagonise(Vector *mat)
        {
            mat[2] = unit_vector (&mat[2]);
        
            if ((mat[2].x > -1) && (mat[2].x < 1))
            {
                if ((mat[2].y > -1) && (mat[2].y < 1))
                {
                    mat[1].z = -(mat[2].x * mat[1].x + mat[2].y * mat[1].y) / mat[2].z;
                }
                else
                {
                    mat[1].y = -(mat[2].x * mat[1].x + mat[2].z * mat[1].z) / mat[2].y;
                }
            }
            else
            {
                mat[1].x = -(mat[2].y * mat[1].y + mat[2].z * mat[1].z) / mat[2].x;
            }
            mat[1] = unit_vector (&mat[1]);
            mat[0].x = mat[1].y * mat[2].z - mat[1].z * mat[2].y;
            mat[0].y = mat[1].z * mat[2].x - mat[1].x * mat[2].z;
            mat[0].z = mat[1].x * mat[2].y - mat[1].y * mat[2].x;
        }
