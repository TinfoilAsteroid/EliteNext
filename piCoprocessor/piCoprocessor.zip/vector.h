#ifndef  VECTOR_H_
#define  VECTOR_H_

class Vector
{
    public:
        double x;
        double y;
        double z;
        Vector()
        {
            x = 1.0;
            y = 0.0;
            z = 0.0;
        }
        Vector (double px,double py,double pz)
        {
            x = px;
            y = py;
            z = pz;
        }
};

class Matrix
{
    public:
        Vector rows[3];
        Matrix ()
        {
            rows[0].x = 1.0;
            rows[0].y = 0.0;
            rows[0].z = 0.0;
            rows[1].x = 0.0;
            rows[1].y = 1.0;
            rows[1].z = 0.0;
            rows[2].x = 0.0;
            rows[2].y = 0.0;
            rows[2].z = -1.0;
        }
};
    
#endif